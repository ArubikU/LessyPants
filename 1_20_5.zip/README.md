Magic Shaders- By ArubikU [​SodaStudio]

This texture pack requires you to apply modifications to your skin by adding an extra layer. Presets are included.

How to get the capes
Go to the folder MagicShaders/capes/<cape_of_election>/ .png
and paste it in your skin

How to get the wings
Go to the folder MagicShaders/wings/<wing_of_election>.png
and paste it in your skin


How to get the Player Modifications
Go to the folder MagicShaders/player_modifications/<player_modification_of_election>.png
and paste it in your skin

now put the resourcepack without MagicShaders/capes , MagicShaders/wings and MagicShaders/player_modifications.

*Only use capes or wings dont both at the same time
*Modifications can use free, without take care of wings or capes


|Capes| | | | |
|--|--|--|--|--|
| amatis cape | bee cape | blaze cape | rabit cape | classic mojang cape |
| coblat cape | glow cape | gold cape | magma cube cape | migrator cape |
| minecon 2019 cape | minecon 2016 cape | mojang studios cape | mojiro cape | netherite cape |
| 8 bits cape | pride cape | slime cape | trans cape | cherry blosoom cape
| ender cape | swords cape| smooth creeper cape | golden creeper cape |
| diamond creeper cape| pancake cape | prismarine cape | scrools cape | spade cape |
| traslator | japanese cape | birthday cape | | |






|Wings| | | | |
|--|--|--|--|--|
| Angel Wings | Phoenix Wings | Nether Wings | Magmatic Wings | Ender Wings |
| Red Mechanical Wings | Silver Mechanical Wings | Mosquitoes Wings | | |


|Player Modifications| | | | |
|--|--|--|--|--|
| Female Chest | Elf Ears | Normal Ears | | |



* You can see a preview of capes from torrezx in
https://www.planetminecraft.com/texture-pack/torrezx-cape-collection/




RoadMap
- Hats
- ????
- ????
- ????

Finished
- Wings [​8/15]
- Capes [​FULL]
- PlayerModifications [​3/15]

Extra:
If you would like to donate or bought the commercial use (One time payment) use my [ko-fi](https://ko-fi.com/arubik)

CREDITS:
Capes made by Torrezx ft. ShadowsCrow
Angel Wings made by JuanT_
Logo icon made by JuanT_
Cem base system by DartCat25 (https://github.com/DartCat25/CEM-S)

NO OPTIFINE NEEDED 🚫
